import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AshwiniComponent } from './components/ashwini/ashwini.component';
import { ActorListComponent } from './components/actor-list/actor-list.component';

@NgModule({
  declarations: [
    AppComponent,
    AshwiniComponent,
    ActorListComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
