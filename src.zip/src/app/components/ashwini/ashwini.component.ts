import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ashwini',
  templateUrl: './ashwini.component.html',
  styleUrls: ['./ashwini.component.css']
})
export class AshwiniComponent implements OnInit {
  secondComponent: string;
  constructor() { }

  ngOnInit() {
    this.secondComponent="Ashwini Second Component";
  }

}
