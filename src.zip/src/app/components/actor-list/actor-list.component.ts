import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actor-list',
  templateUrl: './actor-list.component.html',
  styleUrls: ['./actor-list.component.css']
})
export class ActorListComponent implements OnInit {
 actorList;
 listFlag: boolean;
 btnText: string;
  constructor() { }

  ngOnInit() {
    this .actorList=[
      {name: 'Shahrukh' ,rating:9.5},
      {name: 'Salman' ,rating:8.5},
      {name: 'Alia bhatt' ,rating:1.5},
      {name: 'Kamal hasan' ,rating:6.5},
      {name: 'Rajnikanth' ,rating:9.0}
    ];
    this.listFlag = true;
    this.btnText = 'Hide List';
  }

  toggleList(){
    this.listFlag = !this.listFlag;
    this.btnText = this.listFlag ? 'Hide List' : 'Show List'; // terinary operator
  }

  deleteAction(index){
    this.actorList.splice(index,1); // Splice is  a function to remove or add the element in an array,  '1' to remove one at a item
  }

}
